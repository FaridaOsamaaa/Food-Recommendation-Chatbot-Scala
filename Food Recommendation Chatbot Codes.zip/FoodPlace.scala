package chatbot

import scala.io.Source

case class FoodPlace(
    name: String,
    city: String,
    cuisine: String,
    budget: String,
    rating: Double,
    specialty: String,
    vibe: String
) {

    // =====================================
    // PRINT DETAILS
    // =====================================

    def getDetails(): String = {

        "Name: " + name +
        "\nCity: " + city +
        "\nCuisine: " + cuisine +
        "\nBudget: " + budget +
        "\nRating: " + rating +
        "\nSpecialty: " + specialty +
        "\nVibe: " + vibe +
        "\n"
    }
}

// =====================================
// COMPANION OBJECT
// =====================================

object FoodPlace {

    // =====================================
    // LOAD FOOD PLACES
    // =====================================

    def loadFoodPlaces(
        fileName: String
    ): List[FoodPlace] = {

        val source =
            Source.fromFile(fileName)

        val foodPlaces =
            source
                .getLines()
                .toList
                .map { line =>

                    val data =
                        line.split(",")

                    FoodPlace(
                        data(0).trim,
                        data(1).trim,
                        data(2).trim,
                        data(3).trim,
                        data(4).trim.toDouble,
                        data(5).trim,
                        data(6).trim
                    )
                }

        source.close()

        foodPlaces
    }
}