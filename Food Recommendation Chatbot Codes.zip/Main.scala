package chatbot

object Main {

    def main(
        args: Array[String]
    ): Unit = {

        // =====================================
        // LOAD DATA
        // =====================================

        val foodPlaces =
            FoodPlace.loadFoodPlaces(
                "foodplaces.txt")
            

        // =====================================
        // CREATE USER
        // =====================================

        val user =
            new User()

        // =====================================
        // CREATE CHATBOT
        // =====================================

        val chatbot =
            new Chatbot(
                foodPlaces,
                user
            )

        // =====================================
        // Starting  Chatbot
        // =====================================

        chatbot.startChat()



    }
}