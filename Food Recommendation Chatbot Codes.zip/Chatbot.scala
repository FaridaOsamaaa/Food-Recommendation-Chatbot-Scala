package chatbot

class Chatbot(foodPlaces: List[FoodPlace], user: User) {

    private val chatHistory = new ChatHistory()

    def greetUser(): String = {

        "Hello! Welcome to the Food Recommendation Chatbot.\n" +
        "I can help you discover restaurants based on your preferences."
    }

    def generateResponse(query: String, inputType: String): String = {

        inputType match {

            case "exit" =>
                "Goodbye!"

            case "greeting" =>
                "Hello! What kind of food are you looking for?"

            case "recommend" =>
                recommendPlaces()

            case "budget" | "cuisine" | "vibe" | "city" | "specialty" | "rating" =>

                user.updatePreference(inputType, query)
                analyzePreference(query, inputType)

            case "positiveMood" =>
                "I'm glad you're positive!"

            case "negativeMood" =>
                "I'm sorry to hear that. I'll try to improve the conversation."

            case "preferences" =>
                user.explainPreferences()

            case "removePreferences" =>

                user.clearPreferences()
                "Your preferences were cleared."

            case "history" =>

                chatHistory
                    .getConversationHistory()
                    .map(interaction => interaction._1 + ": " + interaction._2 + "\n")
                    .foldLeft("")((currentText, interaction) => currentText + interaction)

            case "summary" =>
                chatHistory.summarizeConversation()

            case "mostdiscussedtopic" =>
                chatHistory.getMostDiscussedTopics()

            case "mood" =>
                "Your overall mood seems " + chatHistory.getUserMood()

            case _ =>
                "Sorry, I didn't understand."
        }
    }

    def analyzePreference(query: String, preferenceType: String): String = {

        if (chatHistory.detectRepeatedQuery(query)) {

            println("It seems you've mentioned that before.")
        }

        preferenceType match {

            case "budget" =>
                "Budget preference updated."

            case "cuisine" =>
                "Nice! You like " + query + " food."

            case "vibe" =>
                "You're looking for a " + query + " atmosphere."

            case "city" =>
                "You're searching in " + query + "."

            case "specialty" =>
                "You're interested in " + query + "."

            case "rating" =>
                "You prefer places around rating " + query + "."

            case _ =>
                "Preference updated."
        }
    }

    def recommendPlaces(): String = {

        val preferences = user.getPreferences()

        val matches = foodPlaces.filter { place =>

            (preferences.city == "" || place.city.toLowerCase == preferences.city.toLowerCase) &&
            (preferences.cuisine == "" || place.cuisine.toLowerCase.contains(preferences.cuisine.toLowerCase)) &&
            (preferences.budget == "" || place.budget.toLowerCase == preferences.budget.toLowerCase) &&
            (preferences.vibe == "" || place.vibe.toLowerCase == preferences.vibe.toLowerCase) &&
            (preferences.specialty == "" || place.specialty.toLowerCase.contains(preferences.specialty.toLowerCase)) &&
            (preferences.rating == 0.0 || place.rating >= preferences.rating)
        }

        if (matches.isEmpty) {

            "I couldn't find matching places."

        } else {

            val recommendations =
                matches
                    .take(5)
                    .map(place =>
                        "- " +
                        place.name +
                        " | " +
                        place.city +
                        " | " +
                        place.cuisine +
                        " | Rating: " +
                        place.rating +
                        "\n"
                    )
                    .foldLeft("")((currentText, recommendation) => currentText + recommendation)

            "Here are some recommendations:\n\n" +
            recommendations +
            "\nThese recommendations were chosen because:\n" +
            user.explainPreferences()
        }
    }

    def startChat(): Unit = {

        var continue = true

        println(greetUser())

        while (continue) {

            print("\nYou: ")

            val input = InputHandler.handleUserInput()

            val parsedInput = InputHandler.parseInput(input)

            val query = parsedInput._1
            val inputType = parsedInput._2

            chatHistory.logMessage('u', query, inputType)

            val response = generateResponse(query, inputType)

            chatHistory.logMessage('b', response, "response")

            println("\nBot: " + response)

            if (inputType == "exit") {

                continue = false
            }
        }
    }
}