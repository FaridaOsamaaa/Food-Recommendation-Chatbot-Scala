package chatbot

class ChatHistory {

    private var history = List[(Char, String, String)]()

    def logMessage(sender: Char, message: String, messageType: String): Unit = {

        history =
            history :+
            (
                sender,
                message,
                messageType
            )
    }

    def getConversationHistory(): List[(Char, String, String)] = {

        history
    }

    def getLastNInteractions(n: Int): List[(Char, String, String)] = {

        history.takeRight(n)
    }

    def detectRepeatedQuery(input: String): Boolean = {

        val repeatedCount =
            history.count(interaction =>
                interaction._1 == 'u' &&
                interaction._2.toLowerCase.contains(input.toLowerCase)
            )

        repeatedCount >= 2
    }

    def extractTopics(): List[String] = {

        history
            .filter(_._1 == 'u')
            .map(_._3)
            .distinct
    }

    def summarizeConversation(): String = {

        val topics = extractTopics()

        val topicText =
            topics.foldLeft("")((currentText, topic) =>
                if (currentText == "") {
                    topic
                } else {
                    currentText + ", " + topic
                }
            )

        "We discussed: " + topicText + "."
    }

    def getMostDiscussedTopics(): String = {

        if (history.nonEmpty) {

            val topTopic =
                history
                    .filter(_._1 == 'u')
                    .groupBy(_._3)
                    .toList
                    .sortBy { case (_, interactions) =>

                        -interactions.length
                    }
                    .head
                    ._1

            "Most discussed topic is (" + topTopic + ") "

        } else {

            "No interactions yet."
        }
    }

    def getUserMood(): String = {

        val positiveWords = List(
            "love", "great", "good", "amazing", "awesome",
            "fantastic", "excellent", "nice", "cool", "perfect",
            "wonderful", "beautiful", "favorite", "best",
            "delicious", "yummy", "fun", "exciting", "happy",
            "enjoy", "enjoying", "liked", "like"
        )

        val negativeWords = List(
            "hate", "bad", "boring", "terrible", "awful",
            "worst", "annoying", "disgusting", "bland", "gross",
            "sad", "angry", "upset", "frustrating", "frustrated",
            "disappointing", "disappointed", "poor", "ugly",
            "dry", "cold", "overpriced", "slow", "confusing",
            "tired", "stressed"
        )

        val userMessages =
            history.filter(_._1 == 'u')

        val positiveCount =
            userMessages.count(interaction =>
                positiveWords.exists(
                    interaction._2.toLowerCase.contains
                )
            )

        val negativeCount =
            userMessages.count(interaction =>
                negativeWords.exists(
                    interaction._2.toLowerCase.contains
                )
            )

        if (positiveCount > negativeCount) {

            "positive"

        } else if (negativeCount > positiveCount) {

            "negative"

        } else {

            "neutral"
        }
    }
}