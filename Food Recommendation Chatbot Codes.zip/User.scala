package chatbot

class User {

    // =====================================
    // USER PREFERENCES
    // =====================================

    private var preferences =
        FoodPlace(
            "",
            "",
            "",
            "",
            0.0,
            "",
            ""
        )

    // =====================================
    // UPDATE PREFERENCE
    // =====================================

    def updatePreference(
        preferenceType: String,
        value: String
    ): Unit = {

        preferences =
            preferenceType match {

                case "city" =>
                    preferences.copy(
                        city = value
                    )

                case "cuisine" =>
                    preferences.copy(
                        cuisine = value
                    )

                case "budget" =>
                    preferences.copy(
                        budget = value
                    )

                case "specialty" =>
                    preferences.copy(
                        specialty = value
                    )

                case "vibe" =>
                    preferences.copy(
                        vibe = value
                    )
                case "rating" =>
                    preferences.copy(
                        rating = value.toDouble
                    )

                case _ =>
                    preferences
            }
    }

    // =====================================
    // GET PREFERENCE
    // =====================================

    def getPreference(
        preferenceType: String
    ): String = {

        preferenceType match {

            case "city" =>
                preferences.city

            case "cuisine" =>
                preferences.cuisine

            case "budget" =>
                preferences.budget

            case "specialty" =>
                preferences.specialty

            case "vibe" =>
                preferences.vibe

            case _ =>
                ""
        }
    }

    // =====================================
    // GET ALL PREFERENCES
    // =====================================

    def getPreferences():
        FoodPlace = {

        preferences
    }

    // =====================================
    // EXPLAIN PREFERENCES
    // =====================================

    def explainPreferences(): String = {

        var explanations =
            List[String]()

        // =====================================
        // CITY
        // =====================================

        if (preferences.city != "") {

            explanations =
                explanations :+
                s"your preferred city is ${preferences.city}"
        }

        // =====================================
        // CUISINE
        // =====================================

        if (preferences.cuisine != "") {

            explanations =
                explanations :+
                s"you enjoy ${preferences.cuisine} cuisine"
        }

        // =====================================
        // BUDGET
        // =====================================

        if (preferences.budget != "") {

            explanations =
                explanations :+
                s"you prefer ${preferences.budget} budget places"
        }

        // =====================================
        // SPECIALTY
        // =====================================

        if (preferences.specialty != "") {

            explanations =
                explanations :+
                s"you are interested in ${preferences.specialty}"
        }

        // =====================================
        // VIBE
        // =====================================

        if (preferences.vibe != "") {

            explanations =
                explanations :+
                s"you like a ${preferences.vibe} atmosphere"
        }

        // =====================================
        // RATING
        // =====================================

        if (preferences.rating != 0.0) {

            explanations =
                explanations :+
                s"you are looking for places rated around ${preferences.rating}"
        }

        // =====================================
        // BUILD STRING USING FOLDLEFT
        // =====================================

        val explanationText =
            explanations.foldLeft("") {

                (currentText, explanation) =>

                    if (currentText == "") {

                        explanation

                    } else {

                        currentText +
                        ", " +
                        explanation
                    }
            }

        // =====================================
        // FINAL RESPONSE
        // =====================================

        if (explanationText == "") {

            "You currently have no saved preferences."

        } else {

            "Your preferences indicate that " +
            explanationText +
            "."
        }
    }

    def clearPreferences(): Unit = {

        preferences =
            FoodPlace(
                "",
                "",
                "",
                "",
                0.0,
                "",
                ""
            )
    }
}
