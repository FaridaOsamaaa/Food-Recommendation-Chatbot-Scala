package chatbot

object InputHandler {

    def handleUserInput(): String = {

        scala.io.StdIn.readLine()
    }

    def parseInput(input: String): (String, String) = {

        val lowerInput =
            input.toLowerCase.trim

        val words =
            lowerInput.split(" ").toList

        val exitKeywords = List(
            "bye",
            "exit",
            "done",
            "goodbye"
        )

        val historyKeywords = List(
            "chat history",
            "show history",
            "show chat",
            "conversation history",
            "previous messages"
        )

        val summaryKeywords = List(
            "summary",
            "summarize",
            "conversation summary"
        )

        val moodQuestionKeywords = List(
            "my mood",
            "what is my mood",
            "how do i feel",
            "detect my mood"
        )

        val preferenceQuestions = List(
            "my preferences",
            "my preference",
            "show my preferences",
            "show my preference",
            "show preferences",
            "show preference",
            "what do i like",
            "what are my preferences",
            "my type"
        )

        val removePreferenceKeywords = List(
            "clear preferences",
            "clear preference",
            "remove preferences",
            "remove preference",
            "reset preferences",
            "reset preference",
            "forget preferences"
        )

        val recommendKeywords = List(
            "recommend",
            "suggest",
            "restaurant",
            "restaurants",
            "recommendation"
        )

        val greetingKeywords = List(
            "hi",
            "hello",
            "hey"
        )

        val mostdiscussedtopic = List(
            "most discussed topic",
            "most discussed",
            "main topic",
            "main discussed topic",
            "most repeated topic",
            "most mentioned topic",
            "main mentioned topic",
            "most talked about topic",
            "main talked about topic"
        )

        val moodKeywords = Map(

            "positiveMood" -> List(
                "love",
                "great",
                "good",
                "amazing",
                "awesome",
                "happy",
                "nice"
            ),

            "negativeMood" -> List(
                "hate",
                "bad",
                "boring",
                "terrible",
                "awful",
                "sad",
                "angry",
                "fuck you"
            )
        )

        val keywordCategories = Map(

            "budget" -> List(

                "cheap",
                "budget",
                "affordable",
                "low budget",
                "inexpensive",

                "medium",
                "average",
                "normal prices",

                "expensive",
                "luxury",
                "high budget",
                "fine dining",
                "premium",
                "fancy"
            ),

            "cuisine" -> List(

                "italian",
                "pizza",
                "pasta",

                "american",
                "burger",
                "burgers",
                "fried chicken",

                "egyptian",
                "koshary",
                "mahshi",
                "hawawshi",

                "japanese",
                "sushi",
                "ramen",

                "seafood",
                "fish",
                "shrimp",

                "syrian",
                "shawarma",

                "indian",
                "butter chicken",
                "curry",

                "turkish",
                "kebab",
                "kofta",

                "desserts",
                "ice cream",
                "cakes",

                "cafe",
                "coffee",
                "pastries",

                "mexican",
                "tacos",

                "fast food",

                "lebanese",

                "bakery",

                "asian",

                "thai"
            ),

            "vibe" -> List(

                "romantic",
                "date",
                "couple",

                "family",
                "family friendly",

                "casual",
                "chill",
                "relaxed",

                "luxury",
                "fancy",
                "elegant",
                "upscale",

                "cozy",
                "quiet",

                "modern",
                "traditional"
            ),

            "city" -> List(

                "cairo",
                "new cairo",
                "zamalek",
                "maadi",
                "nasr city",
                "heliopolis",

                "giza",
                "sheikh zayed",

                "alex",
                "alexandria",

                "mansoura",
                "luxor",
                "aswan",
                "hurghada",
                "sharm el sheikh",
                "el gouna",
                "port said"
            ),

            "specialty" -> List(

                "pizza",
                "margherita pizza",
                "pepperoni pizza",
                "pasta",
                "alfredo pasta",
                "lasagna",
                "risotto",

                "burger",
                "beef burger",
                "cheese burger",
                "fried chicken",
                "hot dogs",
                "bbq ribs",
                "steak",
                "buffalo wings",

                "sushi",
                "salmon sushi",
                "ramen",
                "tempura",
                "udon noodles",

                "koshary",
                "hawawshi",
                "mahshi",
                "molokhia",
                "foul",
                "falafel",
                "kofta",
                "mixed grill",

                "shawarma",
                "chicken shawarma",
                "meat shawarma",
                "manakish",
                "kebab",
                "hummus",
                "fattoush",

                "grilled fish",
                "shrimp",
                "fried shrimp",
                "seafood pasta",
                "calamari",
                "lobster",
                "fish fillet",

                "butter chicken",
                "biryani",
                "curry",
                "naan bread",
                "tandoori chicken",

                "tacos",
                "burritos",
                "quesadilla",
                "nachos",

                "turkish breakfast",
                "iskender kebab",
                "doner",
                "grilled kofta",

                "ice cream",
                "cakes",
                "cheesecake",
                "brownies",
                "cookies",
                "waffles",
                "crepes",
                "croissant",
                "donuts",
                "cinnamon rolls",

                "coffee",
                "iced coffee",
                "espresso",
                "latte",
                "cappuccino",

                "breakfast",
                "english breakfast",
                "pancakes",
                "omelette",
                "french toast",

                "salads",
                "protein bowls",
                "grilled chicken",
                "healthy sandwiches",
                "vegan meals",

                "noodles",
                "dumplings",
                "thai curry",
                "spring rolls",
                "fried rice"
            )
        )

        exitKeywords.find(words.contains) match {

            case Some(keyword) =>

                return (keyword, "exit")

            case None =>
        }

        historyKeywords.find(lowerInput.contains) match {

            case Some(keyword) =>

                return (keyword, "history")

            case None =>
        }

        summaryKeywords.find(lowerInput.contains) match {

            case Some(keyword) =>

                return (keyword, "summary")

            case None =>
        }

        preferenceQuestions.find(lowerInput.contains) match {

            case Some(keyword) =>

                return (keyword, "preferences")

            case None =>
        }

        removePreferenceKeywords.find(lowerInput.contains) match {

            case Some(keyword) =>

                return (keyword, "removePreferences")

            case None =>
        }

        moodQuestionKeywords.find(lowerInput.contains) match {

            case Some(keyword) =>

                return (keyword, "mood")

            case None =>
        }

        mostdiscussedtopic.find(lowerInput.contains) match {

            case Some(keyword) =>

                return (keyword, "mostdiscussedtopic")

            case None =>
        }

        moodKeywords.collectFirst {

            case (moodType, keywords)
                if keywords.exists(words.contains) =>

                (
                    keywords.find(words.contains).get,
                    moodType
                )

        } match {

            case Some(result) =>

                return result

            case None =>
        }

        recommendKeywords.find(words.contains) match {

            case Some(keyword) =>

                return (keyword, "recommend")

            case None =>
        }

        greetingKeywords.find(words.contains) match {

            case Some(keyword) =>

                return (keyword, "greeting")

            case None =>
        }

        keywordCategories.collectFirst {

            case (variableType, keywords)
                if keywords.exists(words.contains) =>

                (
                    keywords.find(words.contains).get,
                    variableType
                )

        } match {

            case Some(result) =>

                result

            case None =>

                (
                    "unknown",
                    "fallback"
                )
        }
    }
}